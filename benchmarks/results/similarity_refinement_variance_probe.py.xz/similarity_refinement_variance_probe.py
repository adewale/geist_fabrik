"""Alternating follow-up for variable cold/dense isolated timings."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
root=Path('/workspace/geist_fabrik')
evidence=Path('/workspace/verification-tools')
rows=[]
for feature in ['prepare','canonical_matrix','threshold_matrix']:
    for phase in ['before','after','after','before']:
        source=Path('/workspace/geist-primitives-regressions-before') if phase=='before' else root
        hashes={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((source/'src/geistfabrik').rglob('*.py'))}
        result=subprocess.run([str(root/'.venv/bin/python'),str(root/'scripts/benchmark_similarity_primitives.py'),
            '--worker',feature,'--phase','after','--trials','15'],cwd=root,
            env=dict(os.environ,PYTHONPATH=str(source/'src'),GEISTFABRIK_OFFLINE='1'),
            capture_output=True,text=True,check=True)
        assert hashes=={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((source/'src/geistfabrik').rglob('*.py'))}
        rows.append({'feature':feature,'phase':phase,'measurement':json.loads(result.stdout),
            'runtime_source_sha256':hashes})
    print(feature,'complete',flush=True)
(evidence/'refinement-variance-abba.json').write_text(json.dumps(rows,indent=2)+'\n')
