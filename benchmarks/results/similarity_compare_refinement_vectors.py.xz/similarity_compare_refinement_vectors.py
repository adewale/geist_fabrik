"""Compare persisted complete embedding rows, streaming immutable replay databases."""
import json
import sqlite3
from pathlib import Path
import numpy as np

results={}
for profile in ['smoke','standard','large']:
    suffix_before=''
    suffix_after='-verified'
    base=Path('/workspace/bidirectional-replays')
    before=base/f'refinement-before-{profile}{suffix_before}/_geistfabrik/vault.db'
    after=base/f'refinement-after-{profile}{suffix_after}/_geistfabrik/vault.db'
    before_final=base/f'refinement-before-{profile}-final/_geistfabrik/vault.db'
    if before_final.exists():before=before_final
    assert before.exists() and after.exists(),profile
    report={'row_pairs':0,'changed_rows':0,'changed_coordinates':0,'maximum_absolute_difference':0.0,'changed_by_session':{}}
    with sqlite3.connect(before.as_uri()+'?mode=ro',uri=True) as db:
        db.execute('ATTACH DATABASE ? AS after',(after.as_uri()+'?mode=ro',))
        query='''SELECT b.date,x.note_path,x.embedding,y.embedding FROM sessions b
        JOIN session_embeddings x ON x.session_id=b.session_id
        JOIN after.sessions a ON a.date=b.date
        JOIN after.session_embeddings y ON y.session_id=a.session_id AND y.note_path=x.note_path'''
        for day,path,left,right in db.execute(query):
            report['row_pairs']+=1
            if left==right:continue
            a=np.frombuffer(left,dtype=np.float32)
            b=np.frombuffer(right,dtype=np.float32)
            assert a.shape==b.shape
            differences=np.abs(a.astype(np.float64)-b.astype(np.float64))
            count=int(np.count_nonzero(a.view(np.uint32)!=b.view(np.uint32)))
            report['changed_rows']+=1
            report['changed_coordinates']+=count
            report['maximum_absolute_difference']=max(report['maximum_absolute_difference'],float(differences.max()))
            report['changed_by_session'][day]=report['changed_by_session'].get(day,0)+1
        report['before_rows']=db.execute('SELECT COUNT(*) FROM session_embeddings').fetchone()[0]
        report['after_rows']=db.execute('SELECT COUNT(*) FROM after.session_embeddings').fetchone()[0]
        assert report['row_pairs']==report['before_rows']==report['after_rows']
    results[profile]=report
Path('/workspace/verification-tools/refinement-vector-comparison.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
