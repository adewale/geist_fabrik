"""Embeddings computation for GeistFabrik."""

import os

# Cap tokenizers' fork-time threading only if the host hasn't expressed a
# preference (it has no threadpoolctl-style runtime API, unlike BLAS/OpenMP).
# Native BLAS/OpenMP thread pools are bounded at the point of use instead, via
# threadpool_limits() around the heavy encode() calls - see EmbeddingComputer.
# This avoids mutating global OMP_NUM_THREADS/etc. at import, which silently
# single-threads any host application that embeds GeistFabrik.
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import hashlib
import logging
import math
import sqlite3
from datetime import datetime
from importlib import resources
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol, cast

import numpy as np
from sentence_transformers import SentenceTransformer
from threadpoolctl import threadpool_limits  # type: ignore[import-untyped]

if TYPE_CHECKING:
    from .vector_search import VectorSearchBackend

from .config import (
    DEFAULT_BATCH_SIZE,
    DEFAULT_SEMANTIC_WEIGHT,
    MODEL_NAME,
    semantic_cache_key,
)
from .models import Note
from .session_time import normalise_session_date
from .sqlite_transaction import owned_transaction
from .text_embeddings import TextEmbeddingCache
from .vector_math import cosine_matrix

logger = logging.getLogger(__name__)


class ConcurrentVaultChangeError(RuntimeError):
    """Raised when embedding inputs become stale before they can be committed."""


class EmbeddingModel(Protocol):
    """Structural interface required from embedding model implementations."""

    def encode(
        self,
        sentences: str | list[str],
        *,
        convert_to_numpy: bool = True,
        show_progress_bar: bool = False,
        batch_size: int = 32,
        **kwargs: Any,
    ) -> np.ndarray:
        """Encode one string or a batch of strings as numpy arrays."""
        ...


# Native BLAS/OpenMP thread cap applied only around model.encode() calls.
# 1 keeps embedding deterministic and prevents the runaway thread-pool
# spawning (one pool per core, per process) that hung CI under parallel geist
# execution - without imposing that cap on the host process globally.
_ENCODE_THREAD_LIMIT = 1

_REQUIRED_MODEL_FILES = (
    "config.json",
    "config_sentence_transformers.json",
    "model.safetensors",
    "modules.json",
    "tokenizer.json",
    "tokenizer_config.json",
    "vocab.txt",
    "1_Pooling/config.json",
)
_LFS_POINTER_PREFIX = b"version https://git-lfs.github.com/spec/v1"


def _is_usable_model_directory(model_path: Path) -> bool:
    """Return whether *model_path* contains a complete, materialised snapshot."""
    if not model_path.is_dir():
        return False
    if any(not (model_path / relative_path).is_file() for relative_path in _REQUIRED_MODEL_FILES):
        logger.warning("Bundled model snapshot is incomplete at %s", model_path)
        return False

    weights_path = model_path / "model.safetensors"
    try:
        with weights_path.open("rb") as weights_file:
            header = weights_file.read(len(_LFS_POINTER_PREFIX))
    except OSError:
        return False
    if weights_path.stat().st_size <= 1000 or header.startswith(_LFS_POINTER_PREFIX):
        logger.warning("Bundled model weights at %s are a Git LFS pointer", weights_path)
        return False
    return True


def _bundled_model_path(model_name: str) -> Path | None:
    """Resolve a bundled model from package resources or a source checkout.

    Installed wheels expose the snapshot through ``geistfabrik.model_data``.
    The repository-level fallback keeps editable/source-checkout behaviour for
    contributors whose Git LFS objects are materialised.
    """
    resource_path = Path(str(resources.files("geistfabrik.model_data").joinpath(model_name)))
    source_path = Path(__file__).resolve().parents[2] / "models" / model_name
    for candidate in dict.fromkeys((resource_path, source_path)):
        if _is_usable_model_directory(candidate):
            return candidate
    return None


def is_offline_mode() -> bool:
    """Whether GeistFabrik must avoid any network access when loading the model.

    Honours GEISTFABRIK_OFFLINE (any truthy value) as well as the standard
    HuggingFace HF_HUB_OFFLINE / TRANSFORMERS_OFFLINE flags. When enabled and no
    local model is available, model loading fails loudly instead of silently
    downloading from HuggingFace - preserving the "local-first, no network"
    guarantee.
    """
    gf_flag = os.environ.get("GEISTFABRIK_OFFLINE", "").strip().lower()
    if gf_flag in {"1", "true", "yes", "on"}:
        return True
    if os.environ.get("HF_HUB_OFFLINE", "") == "1":
        return True
    if os.environ.get("TRANSFORMERS_OFFLINE", "") == "1":
        return True
    return False


def combine_embedding(
    semantic: np.ndarray,
    temporal: np.ndarray,
    semantic_weight: float = DEFAULT_SEMANTIC_WEIGHT,
) -> np.ndarray:
    """Weight and concatenate semantic and temporal features.

    The single implementation of session-embedding composition, used by
    ``Session.compute_embeddings`` and ``EmbeddingComputer.compute_temporal_embedding``.

    Args:
        semantic: Semantic embedding (384 dims in production)
        temporal: Temporal features (3 dims)
        semantic_weight: Weight for the semantic part; temporal gets 1 - weight

    Returns:
        ``concat(semantic * w, temporal * (1 - w))``
    """
    return np.concatenate([semantic * semantic_weight, temporal * (1.0 - semantic_weight)])


class EmbeddingComputer:
    """Handles embedding computation using sentence-transformers."""

    def __init__(
        self,
        model_name: str = MODEL_NAME,
        model: EmbeddingModel | None = None,
    ):
        """Initialise embedding computer.

        Args:
            model_name: Name of sentence-transformers model to use
            model: Pre-initialised model (for testing/injection), if None will lazy-load
        """
        self.model_name = model_name
        self._model: EmbeddingModel | None = model
        self.device: str | None = None  # Will be set on first model access
        self.text_cache = TextEmbeddingCache()

    def _detect_device(self) -> str:
        """Detect best available device for model inference.

        Priority: cuda (NVIDIA GPU) > mps (Apple Silicon) > cpu

        Returns:
            Device string: "cuda", "mps", or "cpu"
        """
        try:
            import torch

            if torch.cuda.is_available():
                return "cuda"
            if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                return "mps"
        except ImportError:
            # torch not available, fall back to CPU
            pass

        return "cpu"

    @property
    def model(self) -> EmbeddingModel:
        """Lazy-load the sentence-transformers model.

        Checks the packaged model resource first, then the source-checkout
        model directory, and finally falls back to HuggingFace cache/download.

        Auto-detects best available device (CUDA > MPS > CPU).
        """
        if self._model is None:
            # Detect device if not already set
            if self.device is None:
                self.device = self._detect_device()
                logger.info(f"Using device: {self.device}")

            local_model_path = _bundled_model_path(self.model_name)
            offline = is_offline_mode()
            if local_model_path is not None:
                model_source = str(local_model_path)
            elif offline:
                source_path = Path(__file__).resolve().parents[2] / "models" / self.model_name
                raise RuntimeError(
                    "Offline mode is enabled but the installed distribution has no usable "
                    f"bundled model resource for '{self.model_name}'. If this is a source "
                    f"checkout, materialise Git LFS files at {source_path} with 'git lfs pull'. "
                    "Otherwise reinstall an official wheel, or unset the offline flags to "
                    "allow the HuggingFace fallback."
                )
            else:
                model_source = self.model_name

            loaded_model = SentenceTransformer(
                model_source,
                device=self.device,  # Use detected device (cuda/mps/cpu)
                local_files_only=offline,
            )
            # sentence-transformers exposes a large overloaded encode() API whose
            # third-party annotations do not narrow to its numpy-returning mode.
            # Runtime arguments above enforce the EmbeddingModel contract.
            self._model = cast(EmbeddingModel, loaded_model)
        model = self._model
        assert model is not None
        return model

    def compute_semantic(self, text: str) -> np.ndarray:
        """Compute semantic embedding for text.

        Args:
            text: Text to embed

        Returns:
            384-dimensional semantic embedding
        """
        result: np.ndarray = self.compute_batch_semantic([text])[0]
        return result

    def compute_batch_semantic(self, texts: list[str], batch_size: int = 32) -> np.ndarray:
        """Compute semantic embeddings for multiple texts in batch.

        This is significantly faster than calling compute_semantic() in a loop,
        as it leverages batched matrix operations.

        Args:
            texts: List of texts to embed
            batch_size: Batch size for encoding (default: 32)

        Returns:
            NxM numpy array where N is number of texts and M is embedding dimension (384)
        """
        if not texts:
            return np.array([])

        model = self.model

        def encode(missing: list[str]) -> np.ndarray:
            with threadpool_limits(limits=_ENCODE_THREAD_LIMIT):
                return model.encode(
                    missing,
                    convert_to_numpy=True,
                    show_progress_bar=False,
                    batch_size=batch_size,
                )

        return self.text_cache.encode(
            texts,
            encode,
            identity=(id(model), self.model_name, self.device),
        )

    def compute_temporal_features(self, note: Note, session_date: datetime) -> np.ndarray:
        """Compute temporal features for a note.

        Args:
            note: Note to compute features for
            session_date: Current session date

        Returns:
            3-dimensional temporal features:
            - note_age: days since note creation
            - creation_season: sine of creation day-of-year
            - session_season: sine of session day-of-year
        """
        # Sessions are calendar-day identities.  Compare calendar dates rather
        # than elapsed 24-hour periods so time-of-day cannot move a note across
        # an age boundary during replay.
        age_days = (session_date.date() - note.created.date()).days
        note_age = age_days / 365.0  # Normalise to years

        # Creation season (cyclical encoding)
        creation_doy = note.created.timetuple().tm_yday
        creation_season = math.sin(2 * math.pi * creation_doy / 365.0)

        # Session season (cyclical encoding)
        session_doy = session_date.timetuple().tm_yday
        session_season = math.sin(2 * math.pi * session_doy / 365.0)

        return np.array([note_age, creation_season, session_season])

    def compute_temporal_embedding(
        self, note: Note, session_date: datetime, semantic_weight: float = DEFAULT_SEMANTIC_WEIGHT
    ) -> np.ndarray:
        """Compute combined temporal embedding.

        Args:
            note: Note to embed
            session_date: Current session date
            semantic_weight: Weight for semantic component (0-1)

        Returns:
            387-dimensional embedding (384 semantic + 3 temporal)
        """
        return combine_embedding(
            self.compute_semantic(note.content),
            self.compute_temporal_features(note, session_date),
            semantic_weight,
        )

    def close(self) -> None:
        """Clean up model resources."""
        if hasattr(self, "text_cache"):
            self.text_cache.clear()
        if self._model is not None:
            self._model = None

    def __enter__(self) -> "EmbeddingComputer":
        """Context manager entry."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        """Context manager exit."""
        self.close()

    def __del__(self) -> None:
        """Cleanup when object is garbage collected."""
        self.close()


class Session:
    """Represents a GeistFabrik session with temporal embeddings."""

    def __init__(
        self,
        date: datetime,
        db: sqlite3.Connection,
        computer: EmbeddingComputer | None = None,
        backend: str = "in-memory",
        embedding_retention: int | None = None,
    ):
        """Initialise session.

        Args:
            date: Session date
            db: Database connection
            computer: EmbeddingComputer instance (for testing/injection), if None will create new
            backend: Vector search backend to use ('in-memory' or 'sqlite-vec')
            embedding_retention: Maximum number of recent sessions to retain temporal
                embeddings for. Sessions older than this are pruned at the start of
                each session to bound database growth. None or <= 0 retains all.
        """
        self.date = normalise_session_date(date)
        self.db = db
        self.session_id = self._get_or_create_session()
        self._snapshot_data_version = self._read_data_version()
        self.computer = computer if computer is not None else EmbeddingComputer()
        self._owns_computer = computer is None
        self._backend_type = backend
        self._backend: VectorSearchBackend | None = None
        self.embedding_retention = embedding_retention
        self._computed_inputs: list[tuple[str, str, str, str]] | None = None
        self._computed_token: tuple[int, int, datetime, int | None, int] | None = None

    def close(self) -> None:
        """Release resources owned by this session, leaving its shared DB open.

        Sessions remain reusable: another get_backend() loads a fresh projection.
        An injected EmbeddingComputer belongs to its caller and is never closed.
        Use this method or a context manager for deterministic projection cleanup.
        """
        try:
            if self._backend is not None:
                self._backend.close()
                self._backend = None
        finally:
            self._computed_inputs = None
            self._computed_token = None
            if self._owns_computer:
                self.computer.close()

    def __enter__(self) -> "Session":
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        if exc_type is None:
            self.close()
            return
        try:
            self.close()
        except Exception:
            # Context-manager cleanup must not replace the body exception.
            logger.warning("Session cleanup failed while handling an exception", exc_info=True)

    def __del__(self) -> None:
        # Best effort for abandoned sessions. Explicit close/context ownership
        # remains necessary if GC runs after connection shutdown or during a
        # caller-owned transaction: cleanup must not commit that caller's work.
        try:
            self.close()
        except (AttributeError, sqlite3.Error, RuntimeError):
            pass

    def _get_or_create_session(self) -> int:
        """Atomically get or create the canonical session ID for this date."""
        date_str = self.date.strftime("%Y-%m-%d")
        with owned_transaction(self.db, "Session creation"):
            self.db.execute(
                """
                INSERT INTO sessions (date, created_at)
                VALUES (?, ?)
                ON CONFLICT(date) DO NOTHING
                """,
                (date_str, datetime.now().isoformat()),
            )
            row = self.db.execute(
                "SELECT session_id FROM sessions WHERE date = ?", (date_str,)
            ).fetchone()
            if row is None:
                raise sqlite3.DatabaseError("Session upsert returned no row")
            session_id = int(row[0])
        return session_id

    def compute_vault_state_hash(self, notes: list[Note]) -> str:
        """Compute hash of vault state for change detection.

        Args:
            notes: List of all notes

        Returns:
            SHA256 hash of vault state
        """
        hasher = hashlib.sha256()
        for note in sorted(notes, key=lambda n: n.path):
            for value in (
                note.path,
                note.content,
                note.created.isoformat(),
                note.modified.isoformat(),
            ):
                encoded = value.encode()
                hasher.update(len(encoded).to_bytes(8, "big"))
                hasher.update(encoded)
        return hasher.hexdigest()

    def _get_cached_semantic_embedding(self, note: Note) -> np.ndarray | None:
        """Get cached semantic embedding if available and valid.

        Args:
            note: Note to get embedding for

        Returns:
            Cached semantic embedding or None if not found/invalid
        """
        cursor = self.db.execute(
            """
            SELECT embedding FROM embeddings
            WHERE note_path = ? AND model_version = ?
            """,
            (note.path, semantic_cache_key(note.content)),
        )
        row = cursor.fetchone()

        if row is None:
            return None

        # Deserialize from numpy bytes (safe, no code execution risk)
        embedding: np.ndarray = np.frombuffer(row[0], dtype=np.float32)
        return embedding

    def _cache_semantic_embedding(self, note: Note, embedding: np.ndarray) -> None:
        """Cache semantic embedding for a note.

        Args:
            note: Note to cache embedding for
            embedding: Semantic embedding to cache
        """
        # Serialise using numpy's native format (safe, no code execution risk)
        # Store as float32 to reduce storage size (sufficient precision)
        embedding_bytes = embedding.astype(np.float32).tobytes()

        self.db.execute(
            """
            INSERT INTO embeddings (note_path, embedding, model_version, computed_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(note_path) DO UPDATE SET
                embedding = excluded.embedding,
                model_version = excluded.model_version,
                computed_at = excluded.computed_at
            """,
            (
                note.path,
                embedding_bytes,
                semantic_cache_key(note.content),
                datetime.now().isoformat(),
            ),
        )

    def _read_data_version(self) -> int:
        """Read this connection's token for commits made by other connections."""
        row = self.db.execute("PRAGMA data_version").fetchone()
        if row is None:
            raise sqlite3.DatabaseError("Could not read SQLite data_version")
        return int(row[0])

    @staticmethod
    def _embedding_input_snapshot(notes: list[Note]) -> list[tuple[str, str, str, str]]:
        """Return the database-comparable fields that determine embeddings."""
        return sorted(
            (
                note.path,
                note.content,
                note.created.isoformat(),
                note.modified.isoformat(),
            )
            for note in notes
        )

    def _assert_embedding_inputs_are_current(self, notes: list[Note]) -> None:
        """Require every supplied note to match its current committed row."""
        expected = self._embedding_input_snapshot(notes)
        persisted = {
            str(path): (str(content), str(created), str(modified))
            for path, content, created, modified in self.db.execute(
                "SELECT path, content, created, modified FROM notes"
            ).fetchall()
        }
        expected_paths = {row[0] for row in expected}
        inputs_match = (
            len(expected_paths) == len(expected)
            and expected_paths == set(persisted)
            and all(
                persisted[path] == (content, created, modified)
                for path, content, created, modified in expected
            )
        )
        if not inputs_match:
            raise ConcurrentVaultChangeError(
                "Embedding inputs do not match the committed vault snapshot; rerun the "
                "command from a fresh synchronized snapshot"
            )

    def compute_embeddings(self, notes: list[Note]) -> None:
        """Compute and store session embeddings for all notes.

        Uses cached semantic embeddings when available (content unchanged),
        only recomputing temporal features each session for performance.

        Args:
            notes: List of all notes in vault
        """
        if self.db.in_transaction:
            raise RuntimeError("Session.compute_embeddings requires an idle SQLite connection")
        # Compute expensive/model-dependent values before taking SQLite's
        # single-writer lock. data_version is an optimistic-concurrency token:
        # after the lock is acquired we must still be looking at the same
        # committed database state from which caches/notes were read.
        notes = list(notes)  # Note is frozen; detach the caller-owned population list.
        initial_data_version = self._read_data_version()
        if initial_data_version != self._snapshot_data_version:
            self._invalidate_backend()
            raise ConcurrentVaultChangeError(
                "Vault changed before the embedding snapshot was accepted; rerun the command "
                "from a fresh synchronized snapshot"
            )
        inputs = self._embedding_input_snapshot(notes)
        token = (
            initial_data_version,
            self.db.total_changes,
            self.date,
            self.embedding_retention,
            id(self.computer),
        )
        if self._computed_token == token and self._computed_inputs == inputs:
            # A final version check catches a commit during input comparison.
            # No writer lock, vector serialization or backend invalidation is needed.
            if self._read_data_version() != initial_data_version:
                self._invalidate_backend()
                raise ConcurrentVaultChangeError(
                    "Vault changed while embeddings were being checked; rerun the command"
                )
            return
        self._invalidate_backend()
        vault_hash = self.compute_vault_state_hash(notes)

        # Separate notes into cached and uncached
        cached_notes: list[tuple[Note, np.ndarray]] = []
        uncached_notes: list[Note] = []

        for note in notes:
            cached_embedding = self._get_cached_semantic_embedding(note)
            if cached_embedding is not None:
                cached_notes.append((note, cached_embedding))
            else:
                uncached_notes.append(note)

        # Batch compute semantic embeddings for uncached notes only
        semantic_embeddings: dict[str, np.ndarray] = {}

        if uncached_notes:
            texts = [note.content for note in uncached_notes]
            computed_embeddings = self.computer.compute_batch_semantic(
                texts, batch_size=DEFAULT_BATCH_SIZE
            )

            for i, note in enumerate(uncached_notes):
                # Compose from the same representation that semantic-cache reads return.
                semantic = np.asarray(computed_embeddings[i], dtype=np.float32)
                semantic_embeddings[note.path] = semantic

        # Add cached embeddings to lookup dict
        for note, semantic in cached_notes:
            semantic_embeddings[note.path] = semantic

        # Compute temporal features and combine with semantic embeddings
        embedding_rows = []
        for note in notes:
            semantic = semantic_embeddings[note.path]
            temporal = self.computer.compute_temporal_features(note, self.date)
            embedding = combine_embedding(semantic, temporal)

            # Serialise embedding to bytes using numpy's native format (safe)
            # Store as float32 to reduce storage size (sufficient precision for embeddings)
            embedding_bytes = embedding.astype(np.float32).tobytes()

            embedding_rows.append((self.session_id, note.path, embedding_bytes))

        with owned_transaction(self.db, "Session.compute_embeddings"):
            current_data_version = self._read_data_version()
            if current_data_version != initial_data_version:
                raise ConcurrentVaultChangeError(
                    "Vault changed while embeddings were being computed; rerun the command "
                    "from a fresh synchronized snapshot"
                )
            # data_version covers commits after method entry. This exact state
            # comparison also covers a Note list captured before method entry.
            self._assert_embedding_inputs_are_current(notes)
            hash_changed = (
                self.db.execute(
                    "UPDATE sessions SET vault_state_hash = ? WHERE session_id = ? "
                    "AND vault_state_hash IS NOT ?",
                    (vault_hash, self.session_id, vault_hash),
                ).rowcount
                > 0
            )
            before_rows = self.db.total_changes
            self.db.execute(
                "DELETE FROM session_embeddings WHERE session_id = ? AND NOT EXISTS "
                "(SELECT 1 FROM notes WHERE notes.path = session_embeddings.note_path)",
                (self.session_id,),
            )
            removed = self.db.total_changes - before_rows
            for note in uncached_notes:
                self._cache_semantic_embedding(note, semantic_embeddings[note.path])
            before_rows = self.db.total_changes
            self.db.executemany(
                """
                INSERT INTO session_embeddings (session_id, note_path, embedding)
                VALUES (?, ?, ?)
                ON CONFLICT(session_id, note_path) DO UPDATE SET
                    embedding = excluded.embedding, cluster_label = NULL
                WHERE session_embeddings.embedding IS NOT excluded.embedding
                """,
                embedding_rows,
            )
            if hash_changed or removed or self.db.total_changes != before_rows:
                # Cluster labels describe the entire population. A changed row
                # can change another note's membership, so invalidate all labels.
                self.db.execute(
                    "UPDATE session_embeddings SET cluster_label = NULL "
                    "WHERE session_id = ? AND cluster_label IS NOT NULL",
                    (self.session_id,),
                )
            pruned = self._prune_old_session_embeddings()

        self._computed_inputs = inputs
        self._computed_token = (
            initial_data_version,
            self.db.total_changes,
            self.date,
            self.embedding_retention,
            id(self.computer),
        )

        if pruned > 0:
            logger.info(
                f"Pruned {pruned} session-embedding rows beyond retention "
                f"window ({self.embedding_retention} sessions)"
            )

        # Log cache statistics
        total = len(notes)
        cached = len(cached_notes)
        computed = len(uncached_notes)
        cache_hit_rate = (cached / total * 100) if total > 0 else 0
        logger.info(
            f"Embedding cache: {cached}/{total} cached ({cache_hit_rate:.1f}% hit rate), "
            f"{computed} computed"
        )

    def _prune_old_session_embeddings(self) -> int:
        """Delete old temporal embeddings inside the caller-owned transaction.

        Keeps the most recent ``embedding_retention`` sessions (by date) plus the
        current session, and deletes older sessions' rows from session_embeddings
        to bound database growth. Session metadata rows (and tiny session
        suggestions used for novelty history) are left intact - only the bulky
        embedding BLOBs are removed. No-op when retention is None or <= 0.
        """
        retention = self.embedding_retention
        if retention is None or retention <= 0:
            return 0

        # Prune embeddings for every session except the `retention` most recent
        # (ranked by date, excluding the current session so a replayed historical
        # session is never pruned immediately after being written).
        cursor = self.db.execute(
            """
            DELETE FROM session_embeddings
            WHERE session_id IN (
                SELECT session_id FROM sessions
                WHERE session_id != ?
                ORDER BY date DESC
                LIMIT -1 OFFSET ?
            )
            """,
            (self.session_id, retention),
        )
        return cursor.rowcount

    def get_embedding(self, note_path: str) -> np.ndarray | None:
        """Get embedding for a note in this session.

        Args:
            note_path: Path to note

        Returns:
            Embedding array or None if not found
        """
        cursor = self.db.execute(
            """
            SELECT embedding FROM session_embeddings
            WHERE session_id = ? AND note_path = ?
            """,
            (self.session_id, note_path),
        )
        row = cursor.fetchone()

        if row is None:
            return None

        # Deserialize from numpy bytes (safe, no code execution risk)
        embedding: np.ndarray = np.frombuffer(row[0], dtype=np.float32)
        return embedding

    def _create_backend(self) -> "VectorSearchBackend":
        """Create vector search backend based on configuration.

        Returns:
            Initialised VectorSearchBackend

        Raises:
            ValueError: If unknown backend type specified
        """
        from .vector_search import InMemoryVectorBackend, SqliteVecBackend

        if self._backend_type == "in-memory":
            return InMemoryVectorBackend(self.db)
        elif self._backend_type == "sqlite-vec":
            return SqliteVecBackend(self.db)
        else:
            raise ValueError(f"Unknown backend type: {self._backend_type}")

    def _invalidate_backend(self) -> None:
        if self._backend is not None:
            self._backend.close()
            self._backend = None

    def get_backend(self) -> "VectorSearchBackend":
        """Get vector search backend for this session.

        Lazily creates and loads the backend on first access.

        Returns:
            VectorSearchBackend with embeddings loaded
        """
        if self._backend is None or self._backend.closed:
            self._backend = None
            # Only absorb projection-owned writes when the accepted snapshot
            # was still current before loading. Never hide unrelated DB writes.
            accepted = self._computed_token
            projection_only = accepted == (
                self._read_data_version(),
                self.db.total_changes,
                self.date,
                self.embedding_retention,
                id(self.computer),
            )
            backend = self._create_backend()
            session_date = self.date.strftime("%Y-%m-%d")
            try:
                backend.load_embeddings(session_date)
            except BaseException:
                try:
                    backend.close()
                except Exception:
                    logger.warning(
                        "Vector backend cleanup failed after load failure", exc_info=True
                    )
                raise
            self._backend = backend
            if projection_only and accepted is not None:
                self._computed_token = (accepted[0], self.db.total_changes, *accepted[2:])

        return self._backend


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """Compute cosine similarity between two embeddings.

    Args:
        a: First embedding
        b: Second embedding

    Returns:
        Cosine similarity in [-1, 1]
    """
    left, right = np.asarray(a), np.asarray(b)
    if left.shape != right.shape:
        raise ValueError(f"embedding shapes must match, got {left.shape} and {right.shape}")
    return float(cosine_matrix(left.reshape(1, -1), right.reshape(1, -1))[0, 0])


def cosine_similarity_matrix(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Canonical float64 pairwise cosine, identical to the scalar path.

    Finite nonzero vectors retain their direction at every supported magnitude.
    Equal nonzero directions score exactly one; zero rows score zero.
    """
    return cosine_matrix(a, b)


def find_similar_notes(
    query_embedding: np.ndarray,
    embeddings: dict[str, np.ndarray],
    count: int = 10,
    exclude_paths: set[str] | None = None,
) -> list[tuple[str, float]]:
    """Find k most similar notes to query embedding.

    Args:
        query_embedding: Query embedding
        embeddings: Dictionary of note paths to embeddings
        count: Number of similar notes to return
        exclude_paths: Set of paths to exclude from results

    Returns:
        List of (note_path, similarity) tuples, sorted by similarity descending
    """
    if exclude_paths is None:
        exclude_paths = set()

    # Filter excluded paths
    filtered_paths = [p for p in embeddings.keys() if p not in exclude_paths]

    if not filtered_paths:
        return []

    # Vectorized computation: compute all similarities at once
    embedding_matrix = np.vstack([embeddings[p] for p in filtered_paths])

    query_reshaped = query_embedding.reshape(1, -1)
    similarity_scores = cosine_matrix(query_reshaped, embedding_matrix)[0]

    # Create (path, similarity) tuples
    similarities = [
        (filtered_paths[i], float(similarity_scores[i])) for i in range(len(filtered_paths))
    ]

    # Sort by similarity descending
    similarities.sort(key=lambda x: x[1], reverse=True)

    return similarities[:count]
