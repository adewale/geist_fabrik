"""Fresh Session cost with persistent semantics already cached; no inference.

Run with PYTHONPATH selecting the package source. Output is JSON; timing,
allocation, output hashing and fixture construction use separate boundaries.
"""
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import time
import tracemalloc
from datetime import datetime
import numpy as np
from threadpoolctl import threadpool_limits
import geistfabrik
from geistfabrik.config import semantic_cache_key
from geistfabrik.embeddings import Session
from geistfabrik.models import Note
from geistfabrik.schema import init_db

source=Path(geistfabrik.__file__).resolve().parents[2]
manifest={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest()
          for p in sorted((source/'src/geistfabrik').rglob('*.py'))}
results={}
for count in [1000,10000]:
    when=datetime(2026,1,1)
    raw=np.random.default_rng(20261018).normal(size=(count,384)).astype(np.float32)
    notes=[Note(f'n{i:05d}.md',f'Note {i}',f'Corpus text {i}',[],[],when,when) for i in range(count)]
    samples=[]
    with threadpool_limits(limits=1):
        for trial in range(8):
            db=init_db()
            db.executemany('INSERT INTO notes(path,title,content,created,modified,file_mtime) VALUES(?,?,?,?,?,?)',
                [(n.path,n.title,n.content,when.isoformat(),when.isoformat(),when.timestamp()) for n in notes])
            db.executemany('INSERT INTO embeddings VALUES(?,?,?,?)',
                [(n.path,row.tobytes(),semantic_cache_key(n.content),when.isoformat())
                 for n,row in zip(notes,raw,strict=True)])
            db.commit()
            session=Session(when,db)
            before=db.total_changes
            if trial==7:tracemalloc.start()
            started=time.perf_counter()
            session.compute_embeddings(notes)
            elapsed=time.perf_counter()-started
            changes=db.total_changes-before
            if trial==7:
                current,peak=tracemalloc.get_traced_memory()
                tracemalloc.stop()
            else:samples.append(elapsed)
            digest=hashlib.sha256(b''.join(row[0] for row in db.execute(
                'SELECT embedding FROM session_embeddings ORDER BY note_path'))).hexdigest()
            if trial==0:expected=digest
            assert digest==expected
            assert session.computer._model is None,'fixture accidentally invoked model inference'
            session.close()
            db.close()
    results[str(count)]={'seconds':samples,'median_seconds':statistics.median(samples),
        'traced_peak_bytes':peak,'traced_retained_bytes':current,'sqlite_changes':changes,
        'digest':digest,'encoder_called':False}
assert manifest=={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest()
          for p in sorted((source/'src/geistfabrik').rglob('*.py'))}
print(json.dumps({'features':results,'source_commit':subprocess.check_output(
    ['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),
    'runtime_source_sha256':manifest,'probe_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}))
